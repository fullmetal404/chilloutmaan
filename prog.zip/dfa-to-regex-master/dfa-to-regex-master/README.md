# dfa-to-regex
A Python implementation to convert a Deterministic Finite Automata to Regular Expression using state elimination method
